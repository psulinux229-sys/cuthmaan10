import { MoreHorizontal, TrendingUp } from 'lucide-react';
import { MOCK_GOALS } from '../mockData';
import { Goal } from '../types';

interface DashboardProps {
  onGoalClick: (goal: Goal) => void;
}

export default function Dashboard({ onGoalClick }: DashboardProps) {
  return (
    <div className="flex-1 p-6 lg:p-10 max-w-7xl mx-auto w-full">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div>
          <p className="text-[10px] font-black font-sans text-gray-400 uppercase tracking-[0.2em] mb-2">Dashboard</p>
          <h1 className="text-4xl lg:text-6xl font-bold font-display text-gray-900 tracking-tight">Good Morning.</h1>
        </div>
        <img 
          src="https://api.dicebear.com/7.x/avataaars/svg?seed=Cuthmaan" 
          alt="User" 
          className="w-12 h-12 rounded-xl bg-gray-200 shadow-sm hidden md:block"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10 lg:mb-12">
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 lg:p-8 border border-border shadow-sm">
          <div className="flex justify-between items-start mb-6">
            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Overall Progress</h3>
            <TrendingUp size={20} className="text-brand-primary" />
          </div>
          <div className="flex items-end gap-3 mb-6">
            <span className="text-5xl lg:text-7xl font-bold font-display leading-none">68%</span>
            <p className="text-xs lg:text-sm text-gray-500 mb-2 font-medium">Of Q3 objectives completed.</p>
          </div>
          <div className="h-2.5 lg:h-3 w-full bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-success w-[68%]" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 lg:p-8 border border-border shadow-sm flex flex-col justify-center">
          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6">Active Focus</h3>
          <span className="text-5xl lg:text-7xl font-bold font-display leading-none">4</span>
          <p className="text-xs lg:text-sm text-gray-500 mt-3 font-medium">Goals currently in progress</p>
        </div>
      </div>

      <div className="mb-10 flex justify-between items-center">
        <h2 className="text-2xl font-bold font-display text-gray-900">Active Goals</h2>
        <button className="text-sm font-semibold text-brand-primary hover:underline transition-all">View All</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_GOALS.map((goal) => (
          <div 
            key={goal.id}
            onClick={() => onGoalClick(goal)}
            className="group bg-white rounded-2xl p-6 border border-border shadow-sm hover:shadow-md transition-all cursor-pointer"
          >
            <div className="flex justify-between items-start mb-6">
              <span className="px-3 py-1 bg-gray-100 text-[10px] font-bold text-gray-500 rounded-full tracking-wider uppercase">
                {goal.category}
              </span>
              <button className="text-gray-400 hover:text-gray-600">
                <MoreHorizontal size={20} />
              </button>
            </div>
            
            <h3 className="text-lg font-bold font-display text-gray-900 mb-2 group-hover:text-brand-primary transition-colors">
              {goal.title}
            </h3>
            <p className="text-sm text-gray-500 mb-8 line-clamp-2 h-10">
              {goal.description}
            </p>
            
            <div className="flex justify-between items-end mb-2">
              <span className="text-sm font-bold text-gray-900">{goal.progress}%</span>
              <span className="text-[11px] font-medium text-gray-400">{goal.dueDate}</span>
            </div>
            <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-success transition-all duration-500" 
                style={{ width: `${goal.progress}%` }} 
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
